jQuery(document).ready(function () {

    if (jQuery("#back-to-top").length) {
        var scrollTrigger = 100, // px
            backToTop = function () {
                var scrollTop = jQuery(window).scrollTop();
                if (scrollTop > scrollTrigger) {
                    jQuery("#back-to-top").addClass("show");
                } else {
                    jQuery("#back-to-top").removeClass("show");
                }
            };
        backToTop();
        jQuery(window).on("scroll", function () {
            backToTop();
        });
        jQuery("#back-to-top").on("click", function (e) {
            e.preventDefault();
            jQuery("html,body").animate({
                scrollTop: 0,
            },
                700
            );
        });
    }

    if (jQuery("header").length) {
        var scrollTrigger = 100, // px
            activeTop = function () {
                var scrollTop = jQuery(window).scrollTop();
                if (scrollTop > scrollTrigger) {
                    jQuery("header").addClass("active");
                } else {
                    jQuery("header").removeClass("active");
                }
            };
        activeTop();
        jQuery(window).on("scroll", function () {
            activeTop();
        });
    }

    jQuery(".header-slider").slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        fade: true,
        dots: false,
        autoplay: true,
        infinite: true,
        arrows: false,
        autoplaySpeed: 2000,
    });

    jQuery(".get-involved-slider").slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        dots: false,
        autoplay: false,
        infinite: true,
        arrows: true,
        autoplaySpeed: 2000,
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 5,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                }
            }
        ],
    })

    window.addEventListener('scroll', () => {

        let title = document.querySelectorAll(".charger-box");

        title.forEach((el) => {
            let rect = el.getBoundingClientRect();
            let progress = 40 * rect.y / window.innerHeight;

            el.style.transform = `translatey(${progress}%)`;
        });
    });

    jQuery('.click-section a[href^="#"]').on("click", function (e) {
        e.preventDefault();
        var target = this.hash;
        var $target = jQuery(target);
        var offset = (jQuery(window).width() <= 991) ? $target.offset().top - 130 : $target.offset().top - 150;
        jQuery("html, body")
            .stop()
            .animate(
                {
                    scrollTop: offset,
                },
                900,
                "swing",
                function () {
                    // window.location.hash = target;
                }
            );
    });

});