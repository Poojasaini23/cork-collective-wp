<?php /* Template Name: Get Involved */
get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


        <div class="about-page-section">
            <div class="about-section">
                <div class="container">
                    <?php $fea = get_field("get_involved_option_button");
                    if ($fea == "Show") { ?>
                        <div class="row get-involved-section" id="our-mission">
                            <div class="col-md-12">
                                <h2><?php the_field("get_involved_title"); ?></h2>
                            </div>
                            <div class="col-md-8 our-mission-content">
                                <?php the_field("get_involved_content"); ?>
                            </div>
                            <div class="col-md-4 our-mission-button">
                                <?php
                                $link = get_field('get_involved_button');
                                if ($link) :
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];
                                    $link_target = $link['target'] ? $link['target'] : '_self';
                                ?>
                                    <div class="home-button who-we-are-button get-involved-btn">
                                        <a href="<?php echo esc_url($link_url); ?>" target="<?php echo esc_attr($link_target); ?>">
                                            <?php echo esc_html($link_title); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php }
                    if ($fea == "Hide") { ?>
                    <?php } ?>

                    <?php $fea = get_field("pilot_participants_option_button");
                    if ($fea == "Show") { ?>
                        <div class="row pilot-participant-section">
                            <div class="col-md-12">
                                <h2><?php the_field("pilot_participants_title"); ?></h2>
                            </div>
                            <div class="col-md-8 our-mission-content">
                                <?php the_field("pilot_participants_content"); ?>
                            </div>
                            <div class="col-md-4 our-mission-button">
                                <?php
                                $link = get_field('pilot_participants_button');
                                if ($link) :
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];
                                    $link_target = $link['target'] ? $link['target'] : '_self';
                                ?>
                                    <div class="home-button who-we-are-button get-involved-btn">
                                        <a href="<?php echo esc_url($link_url); ?>" target="<?php echo esc_attr($link_target); ?>">
                                            <?php echo esc_html($link_title); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php }
                    if ($fea == "Hide") { ?>
                    <?php } ?>
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 px-0 get-involved-repeater">
                            <div class="get-involved-slider">
                                <?php if (have_rows('pilot_participants_repeater')) : ?>
                                    <?php while (have_rows('pilot_participants_repeater')) : the_row(); ?>
                                        <div>
                                            <div class="get-involved-slider-description">
                                                <?php
                                                $alt_text = get_sub_field('pilot_participants_repeater_image');

                                                if (!empty($alt_text)) : ?>
                                                    <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endwhile; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php $fea = get_field("download_our_participant_pack_option_button");
            if ($fea == "Show") { ?>
                <div class="our-mission download-our-participant-pack">
                    <div class="container">
                        <div class="row our-mission-description">
                            <div class="col-md-10 mr-auto our-mission-title">
                                <h2><?php the_field("download_our_participant_pack_title"); ?></h2>
                            </div>
                            <div class="col-md-8 our-mission-content">
                                <?php the_field("download_our_participant_pack_content"); ?>
                            </div>
                            <div class="col-md-4 our-mission-button">
                                <?php
                                $link = get_field('download_our_participant_pack_button');
                                if ($link) :
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];
                                    $link_target = $link['target'] ? $link['target'] : '_self';
                                ?>
                                    <div class="home-button who-we-are-button get-involved-btn">
                                        <a href="<?php echo esc_url($link_url); ?>" target="<?php echo esc_attr($link_target); ?>">
                                            <?php echo esc_html($link_title); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php }
            if ($fea == "Hide") { ?>
            <?php } ?>

        </div>


<?php endwhile;
endif; ?>
<?php get_footer() ?>