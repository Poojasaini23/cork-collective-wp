<?php /* Template Name: Event */
get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<!-- section -->
<section class="news-post-section">
    <div class="proud-partners">
        <div class="container">
            <div class="row">
                <div class="col-md-10 mx-auto">
                    <div class="row news-post-content">
                        <?php  $cn=0; if (have_rows('event_post_repeater')) : ?>
                        <?php while (have_rows('event_post_repeater')) : the_row(); ?>

                        <div class="<?php echo $cn % 2 == 0 ? 'cn-left news-post-description' : 'cn-right news-post-description' ?>">

                            <?php if ($cn % 2 === 0) { ?>
                            <div class="col-md-12 events-page-description">
                                <div class="row news-post-desc">
                                    <div class="col-md-5 news-post-img">
                                        <a target="_blank" href="<?php the_sub_field("event_post_repeater_url"); ?>">
                                            <?php
                                        $alt_text = get_sub_field('event_post_repeater_image');
                                        if (!empty($alt_text)) : ?>
                                            <img src="<?php echo esc_url($alt_text['url']); ?>"
                                                title="<?php echo esc_attr($alt_text['title']); ?>"
                                                alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                    <div class="col-md-7 news-post-text">
                                        <a target="_blank" href="<?php the_sub_field("event_post_repeater_url"); ?>">
                                            <h2><?php the_sub_field("event_post_repeater_title"); ?></h2>
                                        </a>
                                        <?php the_sub_field("event_post_repeater_content"); ?>
                                        <a class="read_more_button" target="_blank"
                                            href="<?php the_sub_field("event_post_repeater_url"); ?>">
                                            <?php the_sub_field("event_post_repeater_button");?></a>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>

                            <?php if ($cn % 2 !== 0) { ?>
                            <div class="col-md-12 events-page-description">
                                <div class="row news-post-desc">
                                    <div class="col-md-7 order-md-1 order-12 news-post-text">
                                        <a target="_blank" href="<?php the_sub_field("event_post_repeater_url"); ?>">
                                            <h2><?php the_sub_field("event_post_repeater_title"); ?></h2>
                                        </a>
                                        <?php the_sub_field("event_post_repeater_content"); ?>
                                        <a class="read_more_button" target="_blank"
                                            href="<?php the_sub_field("event_post_repeater_url"); ?>">
                                            <?php the_sub_field("event_post_repeater_button");?></a>
                                    </div>
                                    <div class="col-md-5 order-md-12 order-1 news-post-img">
                                        <a target="_blank" href="<?php the_sub_field("event_post_repeater_url"); ?>">
                                            <?php
                                        $alt_text = get_sub_field('event_post_repeater_image');
                                        if (!empty($alt_text)) : ?>
                                            <img src="<?php echo esc_url($alt_text['url']); ?>"
                                                title="<?php echo esc_attr($alt_text['title']); ?>"
                                                alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </div>

                        <?php $cn++; endwhile;  ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /section -->

<div class="news-section-bottom">
    <div class="container">
        <div class="row news-section-2">
            <div class="col-md-12 news-section-2-description">
                <div class="news-section-2-logo">
                    <img src="<?php the_field("header_logo", "options"); ?>" alt="" />
                </div>
                <?php if ( get_field('download_press_material_title') ) : ?>
                <h2 class="post-title"><?php the_field('download_press_material_title'); ?></h2>
                <?php endif; ?>

                <div class="news-section-2-repeater">
                    <?php  if (have_rows('download_press_materials_repeater')) : ?>
                    <?php while (have_rows('download_press_materials_repeater')) : the_row(); ?>
                    <div class="news-section-2-content">
                        <div class="row news-section-2-content-des">
                            <div class="col-md-8 news-section-2-left-content">
                                <?php the_sub_field("download_press_materials_repeater_content");?>
                            </div>
                            <div class="col-md-4 news-section-2-right-content">
                                <?php
                                $link = get_sub_field('download_press_materials_repeater_button');
                                if ($link) :    
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];
                                    $link_target = $link['target'] ? $link['target'] : '_self';
                                ?>
                                <div class="home-button get-involved-btn">
                                    <a href="<?php echo esc_url($link_url); ?>"
                                        target="<?php echo esc_attr($link_target); ?>">
                                        <?php echo esc_html($link_title); ?>
                                    </a>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endwhile;  ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php endwhile;
endif; ?>
<?php get_footer() ?>