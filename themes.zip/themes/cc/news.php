<?php /* Template Name: News */
get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<!-- section -->
<section class="news-post-section">
    <div class="proud-partners">
        <div class="container">
            <div class="row founding-partners-content">
                <div class="col-md-11 founding-partners-title">
                    <h2 class="post-title"><?php the_field("news_title");?></h2>
                </div>
                <div class="col-md-1 founding-partners-icon tree-icons">
                    <img id="tree-icon" src="<?php the_field("icon_image"); ?>" alt="">
                </div>
            </div>
            <div class="row">
                <div class="col-md-10 mx-auto">
                    <div class="row news-post-content">
                        <?php  if (have_rows('news_post_repeater')) : ?>
                        <?php while (have_rows('news_post_repeater')) : the_row(); ?>
                        <div class="col-md-12 news-post-description">
                            <div class="row news-post-desc">
                                <div class="col-md-3 news-post-img">
                                    <a target="_blank" href="<?php the_sub_field("news_post_repeater_url"); ?>">
                                        <?php
                                        $alt_text = get_sub_field('news_post_repeater_image');
                                        if (!empty($alt_text)) : ?>
                                        <img src="<?php echo esc_url($alt_text['url']); ?>"
                                            title="<?php echo esc_attr($alt_text['title']); ?>"
                                            alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                        <?php endif; ?>
                                    </a>
                                </div>
                                <div class="col-md-9 news-post-text">
                                    <a target="_blank" href="<?php the_sub_field("news_post_repeater_url"); ?>">
                                        <h2><?php the_sub_field("news_post_repeater_title"); ?></h2>
                                    </a>
                                    <span class="publish-date"><?php the_sub_field("news_post_repeater_date"); ?></span>
                                </div>
                            </div>
                        </div>
                        <?php endwhile;  ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /section -->

<div class="news-section-bottom">
    <div class="container">
        <div class="row news-section-2">
            <div class="col-md-12 news-section-2-description">
                <div class="news-section-2-logo">
                    <img src="<?php the_field("header_logo", "options"); ?>" alt="" />
                </div>
                <?php if ( get_field('download_press_material_title') ) : ?>
                <h2 class="post-title"><?php the_field('download_press_material_title'); ?></h2>
                <?php endif; ?>

                <div class="news-section-2-repeater">
                    <?php  if (have_rows('download_press_materials_repeater')) : ?>
                    <?php while (have_rows('download_press_materials_repeater')) : the_row(); ?>
                    <div class="news-section-2-content">
                        <div class="row news-section-2-content-des">
                            <div class="col-md-8 news-section-2-left-content">
                                <?php the_sub_field("download_press_materials_repeater_content");?>
                            </div>
                            <div class="col-md-4 news-section-2-right-content">
                                <?php
                                $link = get_sub_field('download_press_materials_repeater_button');
                                if ($link) :    
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];
                                    $link_target = $link['target'] ? $link['target'] : '_self';
                                ?>
                                <div class="home-button get-involved-btn">
                                    <a href="<?php echo esc_url($link_url); ?>"
                                        target="<?php echo esc_attr($link_target); ?>">
                                        <?php echo esc_html($link_title); ?>
                                    </a>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endwhile;  ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php endwhile;
endif; ?>
<?php get_footer() ?>