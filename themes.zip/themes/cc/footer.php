<!-- footer -->
<?php wp_footer(); ?>


<?php $fea = get_field("stay_in_touch_option_button");
if ($fea == "Show") { ?>
    <div class="stay-in-touch">
        <div class="container">
            <div class="row">
                <div class="col-md-1 stay-in-touch-left">
                    <img src="<?php the_field("stay_in_touch_icon", "option"); ?>" alt="">
                </div>
                <div class="col-md-10 mx-auto stay-in-touch-right">
                    <h2 class="form-title"><?php the_field("stay_in_touch_title", "option"); ?></h2>
                    <?php the_field("stay_in_touch_content", "option"); ?>
                </div>
            </div>
        </div>
    </div>
<?php }
if ($fea == "Hide") { ?>
<?php } ?>


<?php $fea = get_field("our_proud_participants_option_button");
if ($fea == "Show") { ?>
    <div class="our-participants-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 our-participants-section-description">
                    <div class="our-proud-participant-icon">
                        <img src="<?php the_field("icon_image", "option"); ?>" alt="">
                    </div>
                    <div class="our-participants-section-content">
                        <h2><?php the_field("our_proud_participants_title", "option"); ?></h2>
                        <div class="row our-participants-section-repeater">
                            <?php if (have_rows('our_proud_participants_repeater', "option")) : ?>
                                <?php while (have_rows('our_proud_participants_repeater', "option")) : the_row(); ?>
                                    <div class="col-md-2 col-sm-3 col-6 our-participants-section-image">
                                        <div class="our-participants-section-img">
                                            <?php
                                            $alt_text = get_sub_field('repeater_image', "option");

                                            if (!empty($alt_text)) : ?>
                                                <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php }
if ($fea == "Hide") { ?>
<?php } ?>




<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-6 order-md-1 order-2 footer-left-section">
                <a class="footer-navbar-brand" href="<?php echo get_home_url(); ?>">
                    <img src="<?php the_field("footer_logo", "options"); ?>" alt="" />
                </a>
                <?php the_field("footer_content", "option"); ?>
            </div>
            <div class="col-md-6 order-md-2 order-3 footer-right-section">
                <?php
                $defaults = array(
                    'menu' => 'footer menu',
                    'menu_class' => 'nav navbar-nav'
                );
                wp_nav_menu($defaults);
                ?>

                <div class="socia-site-icons row">
                    <?php $Case = get_field('social_media_repeater', "options");
                    if (is_array($Case)) {
                        foreach ($Case as $Case_list) {
                    ?>
                            <div class="social-icon-app">
                                <a target="_blank" href="<?php echo $Case_list['social_media_repeater_url']; ?>">
                                    <?php echo $Case_list['social_media_repeater_text']; ?>
                                </a>
                            </div>
                    <?php
                        }
                    }
                    ?>

                </div>
            </div>

            <div class="col-lg-10 order-md-3 order-1 mr-auto footer-form">
                <h2 class="form-title"><?php the_field("get_in_touch_title", "option"); ?></h2>
                <?php the_field("get_in_touch_content", "option"); ?>
            </div>

        </div>
    </div>




    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const carElement = document.querySelector(".car");

            function isInViewport(element) {
                const rect = element.getBoundingClientRect();
                return (
                    rect.top >= 0 &&
                    rect.left >= 0 &&
                    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
                );
            }

            function onScroll() {
                if (isInViewport(carElement)) {
                    carElement.classList.add("animate");
                    window.removeEventListener("scroll", onScroll); // Remove listener after animation starts
                }
            }

            window.addEventListener("scroll", onScroll);
            onScroll(); // Check if already in viewport
        });
    </script>


    <!-- <link rel="stylesheet" href="https://codepen.io/GreenSock/pen/7ba936b34824fefdccfe2c6d9f0b740b.css" /> -->
    <script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/16327/gsap-latest-beta.min.js?r=5426"></script>
    <script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/16327/ScrollTrigger.min.js"></script>
    <script>
        gsap.to(".tree-icons", {
            yPercent: -15,
            ease: "none",
            scrollTrigger: {
                trigger: "#tree-icon",
                // start: "top bottom", // the default values
                // end: "bottom top",
                scrub: true
            },
        });
    </script>

</footer>
</body>

</html>