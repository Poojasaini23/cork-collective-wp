<!doctype html>
<html <?php language_attributes(); ?> class="no-js">

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <title><?php wp_title(''); ?><?php if (wp_title('', false)) {
                                        echo ' :';
                                    } ?> <?php bloginfo('name'); ?></title>

    <link href="//www.google-analytics.com" rel="dns-prefetch">
    <link rel="shortcut icon" href="<?php echo $logo_image = get_field('favicon_ico', 'option'); ?>">
    <link rel="shortcut icon" href="<?php echo $logo_image = get_field('favicon_png', 'option'); ?>">

    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta name="description" content="<?php bloginfo('description'); ?>">
    <meta name="theme-color" content="#ea562f">
    <meta name="format-detection" content="telephone=no">

    <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/wow.min.js"></script>
    <script>
        new WOW().init({
            mobile: false
        });
    </script>
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/animate.css" />
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/slick.css" />
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/slick-theme.css" />
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/jquery.fancybox.css" />
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/style.css?v=1.30" />

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i&display=swap" rel="stylesheet">

    <?php wp_head(); ?>

    <style>
        <?php echo  get_field('css_text_area', 'option'); ?>
    </style>
</head>

<body <?php body_class(); ?>>
    <a id="back-to-top" class="" href="#"><i class="fa fa-angle-up"></i></a>

    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-12 navigation-section">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand mr-auto rotate " href="<?php echo get_home_url(); ?>">
                            <img src="<?php the_field("header_logo", "options"); ?>" alt="" />
                        </a>
                        <input type="checkbox" id="toggle" style="display:none;">
                        <label class="toggle-btn toggle-btn__cross" for="toggle">

                            <div class="cross-btn-image">
                                <div class="bar"></div>
                                <div class="bar"></div>
                                <div class="bar"></div>
                            </div>
                        </label>
                        <div class="navbar-collapse collapse " id="navbarMobile">
                            <div class="navbar_content">
                                <div class="menu-logo">
                                    <a href="<?php echo get_home_url(); ?>">
                                        <img src="<?php the_field("header_menu_logo", "options"); ?>" alt="" />
                                    </a>
                                </div>
                                <?php
                                $defaults = array(
                                    'menu' => 'header menu',
                                    'menu_class' => 'nav navbar-nav'
                                );
                                wp_nav_menu($defaults);
                                ?>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <?php if (is_home() || is_front_page()) {
    } else { ?>
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                <?php $option = get_field('option_button');

                $banner = get_field('header_image');
                if ($banner == "" || $banner == null || $banner == false) {
                    $banner = get_field('default_banner', "option");
                }
                ?>
                <?php if ($option == "Image") { ?>
                    <div class="header-banner" style="background-image:url('<?php echo $banner ?>');">
                        <img src="<?php echo $banner ?>" style="visibility:hidden; width: 100%;" />
                        <div class="header-banner-description">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-11 header-banner-content">
                                        <h1><?php the_field("header_title"); ?></h1>
                                    </div>
                                </div>
                                <div class="row arrow-section click-section">
                                    <div class="col-md-12">
                                        <div class="arrow">
                                            <a href="<?php the_field("arrow_url"); ?>">
                                                <img src="<?php the_field('arrow_icon'); ?>" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="header-banner-bg-color"></div>
                    </div>
                <?php }
                if ($option == "Video") { ?>
                    <div class="header-banner-video" style="background-image: url(<?php the_field('default_banner', "option"); ?>)">
                        <video autoplay muted loop playsinline preload="auto" id="myVideo" poster="<?php the_field("header_video"); ?>">
                            <source src="<?php the_field("header_video"); ?>" type="video/mp4">
                        </video>
                        <div class="header-banner-description">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-11 header-banner-content">
                                        <h1><?php the_field("header_title"); ?></h1>
                                    </div>
                                </div>
                                <div class="row arrow-section click-section">
                                    <div class="col-md-12">
                                        <div class="arrow">
                                            <a href="<?php the_field("arrow_url"); ?>">
                                                <img src="<?php the_field('arrow_icon'); ?>" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="header-banner-bg-color"></div>
                    </div>
                <?php }
                if ($option == "Slider") { ?>
                    <div class="header-slider">
                        <?php if (have_rows('header_slider')) : ?>
                            <?php while (have_rows('header_slider')) : the_row(); ?>
                                <div class="header-slider-image">
                                    <img src="<?php the_sub_field("header_slider_image"); ?>" alt="">
                                    <div class="header-banner-description">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-11 header-banner-content">
                                                    <h1><?php the_field("header_title"); ?></h1>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="header-banner-bg-color"></div>
                                </div>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                <?php } ?>
        <?php endwhile;
        endif; ?>
    <?php } ?>