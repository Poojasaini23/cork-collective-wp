<?php /* Template Name: About Us */
get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


        <div class="about-page-section">
            <div class="about-section">
                <div class="container">
                    <?php $fea = get_field("who_we_are_option_button");
                    if ($fea == "Show") { ?>
                        <div class="row who-we-are" id="who-we-are">
                            <div class="col-md-12 who-we-are-top-icon tree-icons">
                                <img id="tree-icon" src="<?php the_field("icon_image", "option"); ?>" alt="">
                            </div>
                            <div class="col-md-12 who-we-are-title">
                                <h2><?php the_field("who_we_are_title"); ?></h2>
                            </div>
                            <div class="col-md-8 who-we-are-content">
                                <?php the_field("who_we_are_content"); ?>
                            </div>
                            <div class="col-md-3 who-we-are-button">
                                <?php
                                $link = get_field('who_we_are_button');
                                if ($link) :
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];
                                    $link_target = $link['target'] ? $link['target'] : '_self';
                                ?>
                                    <div class="home-button">
                                        <a href="<?php echo esc_url($link_url); ?>" target="<?php echo esc_attr($link_target); ?>">
                                            <?php echo esc_html($link_title); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-1 who-we-are-icon tree-icons">
                                <img id="tree-icon" src="<?php the_field("icon_image", "option"); ?>" alt="">
                            </div>
                            <div class="col-md-12 what-we-doing-top-icon tree-icons">
                                <img id="tree-icon" src="<?php the_field("icon_image", "option"); ?>" alt="">
                            </div>
                        </div>
                    <?php }
                    if ($fea == "Hide") { ?>
                    <?php } ?>

                    <?php $fea = get_field("what_were_doing_option_button");
                    if ($fea == "Show") { ?>
                        <div class="row what-we-doing">
                            <div class="col-md-12 who-we-are-title">
                                <h2><?php the_field("what_were_doing_title"); ?></h2>
                            </div>
                            <div class="col-md-8 who-we-are-content">
                                <?php the_field("what_were_doing_content"); ?>
                            </div>
                            <div class="col-md-3 who-we-are-button">
                                <?php
                                $link = get_field('what_were_doing_button');
                                if ($link) :
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];
                                    $link_target = $link['target'] ? $link['target'] : '_self';
                                ?>
                                    <div class="home-button">
                                        <a href="<?php echo esc_url($link_url); ?>" target="<?php echo esc_attr($link_target); ?>">
                                            <?php echo esc_html($link_title); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    <?php }
                    if ($fea == "Hide") { ?>
                    <?php } ?>

                </div>
            </div>

            <?php $fea = get_field("founding_partners_option_button");
            if ($fea == "Show") { ?>
                <div class="founding-partners">
                    <div class="container">
                        <div class="row founding-partners-content">
                            <div class="col-md-11 founding-partners-title">
                                <h2><?php the_field("founding_partners_title"); ?></h2>
                            </div>
                            <div class="col-md-1 founding-partners-icon tree-icons">
                                <img id="tree-icon" src="<?php the_field("icon_image", "option"); ?>" alt="">
                            </div>
                        </div>
                        <div class="row founding-partners-repeater">
                            <?php if (have_rows('founding_partners_repeater')) : ?>
                                <?php while (have_rows('founding_partners_repeater')) : the_row(); ?>
                                    <div class="col-md-3 col-6 founding-partners-repeater-content">
                                        <div class="founding-partners-repeater-description">
                                            <div>
                                                <?php
                                                $alt_text = get_sub_field('founding_partners_repeater_image');

                                                if (!empty($alt_text)) : ?>
                                                    <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                                <?php endif; ?>

                                                <?php the_sub_field("founding_partners_repeater_title"); ?>
                                            </div>
                                            <?php
                                            $link = get_sub_field('founding_partners_repeater_button');
                                            if ($link) :
                                                $link_url = $link['url'];
                                                $link_title = $link['title'];
                                                $link_target = $link['target'] ? $link['target'] : '_self';
                                            ?>
                                                <div class="home-buttons">
                                                    <a href="<?php echo esc_url($link_url); ?>" target="<?php echo esc_attr($link_target); ?>">
                                                        <?php echo esc_html($link_title); ?>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php }
            if ($fea == "Hide") { ?>
            <?php } ?>


            <?php $fea = get_field("proud_partners_option_button");
            if ($fea == "Show") { ?>
                <div class="proud-partners">
                    <div class="container">
                        <div class="row proud-partners-content">
                            <div class="col-md-12 proud-partners-title">
                                <h2><?php the_field("proud_partners_title"); ?></h2>
                                <?php the_field("proud_partners_content"); ?>
                            </div>
                        </div>
                        <div class="row proud-partners-repeater">
                            <?php if (have_rows('proud_partners_repeater')) : ?>
                                <?php while (have_rows('proud_partners_repeater')) : the_row(); ?>
                                    <div class="col-sm-4 col-6 proud-partners-repeater-content">
                                        <?php
                                        $alt_text = get_sub_field('proud_partners_repeater_image');

                                        if (!empty($alt_text)) : ?>
                                            <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                        <?php endif; ?>
                                    </div>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php }
            if ($fea == "Hide") { ?>
            <?php } ?>

            <?php $fea = get_field("our_mission_option_button");
            if ($fea == "Show") { ?>
                <div class="our-mission">
                    <div class="container">
                        <div class="row our-mission-description">
                            <div class="col-md-12 our-mission-title">
                                <h2><?php the_field("our_mission_title"); ?></h2>
                            </div>
                            <div class="col-md-8 our-mission-content">
                                <?php the_field("our_mission_content"); ?>
                            </div>
                            <div class="col-md-4 our-mission-button">
                                <?php
                                $link = get_field('our_mission_button');
                                if ($link) :
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];
                                    $link_target = $link['target'] ? $link['target'] : '_self';
                                ?>
                                    <div class="home-button who-we-are-button">
                                        <a href="<?php echo esc_url($link_url); ?>" target="<?php echo esc_attr($link_target); ?>">
                                            <?php echo esc_html($link_title); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php }
            if ($fea == "Hide") { ?>
            <?php } ?>
        </div>


<?php endwhile;
endif; ?>
<?php get_footer() ?>