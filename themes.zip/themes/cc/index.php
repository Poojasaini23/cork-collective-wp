<?php /* Template Name: Home page */
get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

        <div class="desktop-section d-sm-block d-none">
            <div class="index-header-section">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 index-header-section-left">
                            <h1><?php the_field("header_left_title"); ?>
                                <img src="<?php the_field("icon_image", "option"); ?>" alt="">
                            </h1>
                            <div class="index-header-section-left-img">
                                <?php
                                $alt_text = get_field('header_left_image');

                                if (!empty($alt_text)) : ?>
                                    <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                <?php endif; ?>
                            </div>

                            <div class="row index-section-1-left-bottom">
                                <div class="col-md-4 col-2 index-section-1-left-bottom-icon tree-icons">
                                    <img id="tree-icon" src="<?php the_field("icon_image", "option"); ?>" alt="">
                                </div>
                                <div class="col-md-8 col-6 ml-auto index-section-1-left-bottom-img">
                                    <?php
                                    $alt_text = get_field('header_left_image1');

                                    if (!empty($alt_text)) : ?>
                                        <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="index-header-icon tree-icons-animation charger-box">
                            <img class="" src="<?php the_field("icon_image", "option"); ?>" alt="">
                        </div>
                        <div class="col-md-6 index-header-section-right">
                            <div class="index-header-section-right-image">
                                <div class="index-section-1-right-logo">
                                    <?php
                                    $alt_text = get_field('header_right_logo');

                                    if (!empty($alt_text)) : ?>
                                        <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                    <?php endif; ?>
                                </div>

                                <div class="index-header-section-right-img1">
                                    <?php $ver = get_field("header_right_option_button");
                                    if ($ver == "Image") {
                                        $alt_text = get_field('header_right_image');

                                        if (!empty($alt_text)) : ?>
                                            <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                        <?php endif; ?>
                                    <?php }
                                    if ($ver == "Video") { ?>
                                        <video autoplay muted loop playsinline preload="auto" id="myVideo" poster="<?php the_field("header_right_video"); ?>">
                                            <source src="<?php the_field("header_right_video"); ?>" type="video/mp4">
                                        </video>
                                    <?php } ?>
                                </div>
                            </div>
                            <h1><?php the_field("header_right_title"); ?></h1>
                        </div>
                    </div>
                </div>
            </div>

            <?php $fea = get_field("a_joint_initiative_option_button");
            if ($fea == "Show") { ?>
                <div class="sections">
                    <div class="container">
                        <div class="row joint-initiative">
                            <div class="col-md-8 joint-initiative-left">
                                <h2><?php the_field("a_joint_initiative_title"); ?></h2>
                                <div class="joint-initiative-content-desc row">
                                    <div class="col-md-10">
                                        <div class="joint-initiative-content">
                                            <?php the_field("a_joint_initiative_content"); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-2 joint-initiative-content-icon tree-icons">
                                        <img id="tree-icon" class="" src="<?php the_field("icon_image", "option"); ?>" alt="">
                                    </div>
                                </div>
                                <div class="joint-initiative-left-image">
                                    <?php if (have_rows('a_joint_initiative_repeater')) : ?>
                                        <?php while (have_rows('a_joint_initiative_repeater')) : the_row(); ?>
                                            <div class="joint-initiative-left-img">
                                                <?php
                                                $alt_text = get_sub_field('a_joint_initiative_repeater_image');

                                                if (!empty($alt_text)) : ?>
                                                    <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                                <?php endif; ?>
                                            </div>
                                        <?php endwhile; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-4 joint-initiative-right">
                                <?php
                                $alt_text = get_field('a_joint_initiative_image');

                                if (!empty($alt_text)) : ?>
                                    <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php }
            if ($fea == "Hide") { ?>
            <?php } ?>

            <?php $fea = get_field("section_3_option_button");
            if ($fea == "Show") { ?>

                <div class="sections">
                    <div class="container">
                        <div class="row Home-section-3">
                            <div class="col-md-1 Home-section-3-left tree-icons">
                                <img id="tree-icon" src="<?php the_field("icon_image", "option"); ?>" alt="">
                            </div>
                            <div class="col-md-10 ml-auto Home-section-3-right">
                                <?php the_field("section_3_title"); ?>
                            </div>
                        </div>
                    </div>
                </div>

            <?php }
            if ($fea == "Hide") { ?>
            <?php } ?>


            <?php $fea = get_field("section_3_option_button");
            if ($fea == "Show") { ?>

                <div class="home-section-4">
                    <div class="container">
                        <div class="row Home-section-4">
                            <div class="col-sm-4 Home-section-4-left">
                                <?php
                                $alt_text = get_field('section_4_left_image');

                                if (!empty($alt_text)) : ?>
                                    <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="col-sm-8 Home-section-4-right">

                                <h2><?php the_field("section_4_title"); ?></h2>

                                <div class="row Home-section-4-right-description">
                                    <div class="col-sm-5 Home-section-4-right-image1">
                                        <?php
                                        $alt_text = get_field('section_4_right_image');

                                        if (!empty($alt_text)) : ?>
                                            <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-sm-7 Home-section-4-right-image2">
                                        <?php
                                        $alt_text = get_field('section_4_right_image1');

                                        if (!empty($alt_text)) : ?>
                                            <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-xl-7 col-md-8 Home-section-4-right-content">
                                        <?php the_field("section_4_content"); ?>
                                        <div class="Home-section-4-bottom-right">
                                            <?php
                                            $link = get_field('section_4_button');
                                            if ($link) :
                                                $link_url = $link['url'];
                                                $link_title = $link['title'];
                                                $link_target = $link['target'] ? $link['target'] : '_self';
                                            ?>
                                                <div class="home-button">
                                                    <a href="<?php echo esc_url($link_url); ?>" target="<?php echo esc_attr($link_target); ?>">
                                                        <?php echo esc_html($link_title); ?>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-xl-5 col-md-4 Home-section-4-right-icon tree-icons">
                                        <img id="tree-icon" src="<?php the_field("icon_image", "option"); ?>" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php }
            if ($fea == "Hide") { ?>
            <?php } ?>
        </div>

        <div class="mobile-section d-sm-none d-block">
            <div class="index-header-section">
                <div class="container">
                    <div class="row">
                        <div class="col-12 index-header-section-left">
                            <h1><?php the_field("header_left_title"); ?>
                                <img src="<?php the_field("icon_image", "option"); ?>" alt="">
                            </h1>
                        </div>
                    </div>
                </div>
                <div class="index-header-section-left-img">
                    <?php
                    $alt_text = get_field('header_left_image');

                    if (!empty($alt_text)) : ?>
                        <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                    <?php endif; ?>
                </div>
                <div class="container">
                    <div class="row index-section-1-left-bottom">
                        <div class="col-2 index-section-1-left-bottom-icon tree-icons">
                            <img id="tree-icon" src="<?php the_field("icon_image", "option"); ?>" alt="">
                        </div>
                        <div class="col-6 ml-autos index-section-1-left-bottom-img">
                            <?php
                            $alt_text = get_field('header_left_image1');

                            if (!empty($alt_text)) : ?>
                                <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-12 index-header-section-right">
                            <h1><?php the_field("header_right_title"); ?></h1>
                        </div>
                    </div>
                </div>
                <div class="index-header-section-right-image">
                    <div class="index-header-section-right-img1">
                        <?php $ver = get_field("header_right_option_button");
                        if ($ver == "Image") {
                            $alt_text = get_field('header_right_image');

                            if (!empty($alt_text)) : ?>
                                <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                            <?php endif; ?>
                        <?php }
                        if ($ver == "Video") { ?>
                            <video autoplay muted loop playsinline preload="auto" id="myVideo" poster="<?php the_field("header_right_video"); ?>">
                                <source src="<?php the_field("header_right_video"); ?>" type="video/mp4">
                            </video>
                        <?php } ?>
                    </div>
                </div>

            </div>

            <?php $fea = get_field("a_joint_initiative_option_button");
            if ($fea == "Show") { ?>
                <div class="sections">
                    <div class="container">
                        <div class="row joint-initiative">
                            <div class="col-12 joint-initiative-left">
                                <h2><?php the_field("a_joint_initiative_title"); ?></h2>
                                <div class="joint-initiative-content-desc row">
                                    <div class="col-12">
                                        <div class="joint-initiative-content">
                                            <?php the_field("a_joint_initiative_content"); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row joint-initiative-left-image">
                                    <?php if (have_rows('a_joint_initiative_repeater')) : ?>
                                        <?php while (have_rows('a_joint_initiative_repeater')) : the_row(); ?>
                                            <div class="col-6 joint-initiative-left-img">
                                                <?php
                                                $alt_text = get_sub_field('a_joint_initiative_repeater_image');

                                                if (!empty($alt_text)) : ?>
                                                    <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                                <?php endif; ?>
                                            </div>
                                        <?php endwhile; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="joint-initiative-right">
                        <div class="col-12 joint-initiative-content-icon tree-icons">
                            <img id="tree-icon" class="" src="<?php the_field("icon_image", "option"); ?>" alt="">
                        </div>
                        <?php
                        $alt_text = get_field('a_joint_initiative_image');

                        if (!empty($alt_text)) : ?>
                            <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                        <?php endif; ?>
                    </div>
                </div>
            <?php }
            if ($fea == "Hide") { ?>
            <?php } ?>

            <?php $fea = get_field("section_3_option_button");
            if ($fea == "Show") { ?>

                <div class="sections">
                    <div class="container">
                        <div class="row Home-section-3">
                            <div class="col-12 Home-section-3-right">
                                <?php the_field("section_3_title"); ?>
                            </div>
                        </div>
                    </div>
                </div>

            <?php }
            if ($fea == "Hide") { ?>
            <?php } ?>


            <?php $fea = get_field("section_3_option_button");
            if ($fea == "Show") { ?>

                <div class="home-section-4">
                    <div class="Home-section-4-right-image2">
                        <?php
                        $alt_text = get_field('section_4_right_image1');

                        if (!empty($alt_text)) : ?>
                            <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                        <?php endif; ?>
                    </div>
                    <div class="container">
                        <div class="row Home-section-4">
                            <div class="col-12 Home-section-4-right">
                                <h2><?php the_field("section_4_title"); ?></h2>

                                <?php
                                $alt_text = get_field('mobile_image1');

                                if (!empty($alt_text)) : ?>
                                    <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="Home-section-4-right-image1">
                        <?php
                        $alt_text = get_field('mobile_image2');

                        if (!empty($alt_text)) : ?>
                            <img src="<?php echo esc_url($alt_text['url']); ?>" title="<?php echo esc_attr($alt_text['title']); ?>" alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                        <?php endif; ?>
                    </div>
                    <div class="container">
                        <div class="row Home-section-4">
                            <div class="col-12 Home-section-4-right-content">
                                <?php the_field("section_4_content"); ?>
                                <div class="Home-section-4-bottom-right">
                                    <?php
                                    $link = get_field('section_4_button');
                                    if ($link) :
                                        $link_url = $link['url'];
                                        $link_title = $link['title'];
                                        $link_target = $link['target'] ? $link['target'] : '_self';
                                    ?>
                                        <div class="home-button">
                                            <a href="<?php echo esc_url($link_url); ?>" target="<?php echo esc_attr($link_target); ?>">
                                                <?php echo esc_html($link_title); ?>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php }
            if ($fea == "Hide") { ?>
            <?php } ?>
        </div>




<?php endwhile;
endif; ?>
<?php get_footer() ?>