<?php /* Template Name: Survey */
get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="survey-page">
    <div class="survey-section-1">
        <div class="about-page-section">
            <div class="proud-partners" id="proudpartners">
                <div class="container">
                    <div class="row impact-overview-section">
                        <div class="col-md-12 who-we-are-top-icon tree-icons">
                            <img id="tree-icon" src="<?php the_field("icon_image", "option"); ?>" alt="">
                        </div>
                        <div class="col-md-9 impact-overview-content">
                            <?php the_field("section_1_content"); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="survey-form-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 survey-form">
                    <?php $alt_text = get_field('section_1_image'); if (!empty($alt_text)) : ?>
                    <img src="<?php echo esc_url($alt_text['url']); ?>"
                        title="<?php echo esc_attr($alt_text['title']); ?>"
                        alt="<?php echo esc_attr($alt_text['caption']); ?>" />
                    <?php endif; ?>
                    <?php the_content(); ?>
                </div>
            </div>
        </div>
    </div>




</div>

<?php endwhile;
endif; ?>
<?php get_footer() ?>